require 'rails_helper'

RSpec.describe SessionController, type: :controller do

end
