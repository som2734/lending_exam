class LendingController < ApplicationController

end
